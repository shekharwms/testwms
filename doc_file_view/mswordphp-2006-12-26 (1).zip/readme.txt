Class : clsWord

This class is really very helpful if we want to interact with Microsoft Application using PHP 5.1.4. It lets user insert text into MS Word in run time. It can also insert data in a specified location in MS Word Document using Bookmark feature. The class is under process of development furthermore we can also insert image in the word document in run time. Please feel free to contact me anytime on the following mentioned email ids.

For Installaton ..
	
	1. Unzip files under www or public_html folder.
	2. Create one MS Word file name Doc1.doc under c:/ . Note : This location can be changed in index.php file as per your need.
	3. Run index.php file from localhost or remote server as per your Apache configuration.


About myself:

I am a PHP programmer working as Sr. Developer.

Please rate this class If you find it useful. Please feel free to contact me for queries related to this class. I would feel gratefull if i can sort out your issues related to PHP.

Thanks in advance.

Neeraj Thakur
Sr.. Developer
Emails:
	neerajth@gmail.com
	neeraj_th@yahoo.com